package com.swp391.school_medical_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolMedicalManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
