package com.swp391.school_medical_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolMedicalManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolMedicalManagementApplication.class, args);
	}
}
