package com.swp391.school_medical_management.modules.users.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.swp391.school_medical_management.modules.users.dtos.request.HealthCheckProgramRequest;
import com.swp391.school_medical_management.modules.users.dtos.request.VaccineProgramRequest;
import com.swp391.school_medical_management.modules.users.dtos.response.HealthCheckProgramDTO;
import com.swp391.school_medical_management.modules.users.dtos.response.VaccineProgramDTO;
import com.swp391.school_medical_management.modules.users.services.impl.AdminService;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;





@Validated
@RestController
@RequestMapping("api/admin")
@PreAuthorize("hasRole('ROLE_ADMIN')")
public class AdminController {
    
    @Autowired
    private AdminService adminService;

    @PostMapping("/health-check-program")
    public ResponseEntity<HealthCheckProgramDTO> createHealthCheckProgram(@Valid @RequestBody HealthCheckProgramRequest request) {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        HealthCheckProgramDTO healthCheckProgramDTO = adminService.createHealthCheckProgram(request, Long.parseLong(adminId));
        return ResponseEntity.status(HttpStatus.CREATED).body(healthCheckProgramDTO);
    }

    @PutMapping("/health-check-program/{id}")
    public ResponseEntity<HealthCheckProgramDTO> updateHealthCheckProgram(@Valid @RequestBody HealthCheckProgramRequest request, @PathVariable Long id) {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        HealthCheckProgramDTO healthCheckProgramDTO = adminService.updateHealthCheckProgram(id, request, Long.parseLong(adminId));
        return ResponseEntity.ok(healthCheckProgramDTO);
    }

    @GetMapping("/health-check-program")
    public ResponseEntity<List<HealthCheckProgramDTO>> getAllHealthCheckProgram() {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        List<HealthCheckProgramDTO> healthCheckProgramList = adminService.getAllHealthCheckProgram(Long.parseLong(adminId));
        return ResponseEntity.ok(healthCheckProgramList);
    }
    
    @GetMapping("/health-check-program/{id}")
    public ResponseEntity<HealthCheckProgramDTO> getAllHealthCheckProgramById(@PathVariable Long id) {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        HealthCheckProgramDTO healthCheckProgramDTO = adminService.getHealthCheckProgramById(Long.parseLong(adminId), id);
        return ResponseEntity.ok(healthCheckProgramDTO);
    }

    @DeleteMapping("/health-check-program/{id}")
    public ResponseEntity<Void> deleteHealthCheckProgram(@PathVariable Long id) {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        adminService.deleteHealthCheckProgram(Long.parseLong(adminId), id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/vaccine-program")
    public ResponseEntity<VaccineProgramDTO> createVaccineProgram(@RequestBody VaccineProgramRequest request) {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        VaccineProgramDTO vaccineProgramDTO = adminService.createVaccineProgram(request, Long.parseLong(adminId));
        return ResponseEntity.status(HttpStatus.CREATED).body(vaccineProgramDTO);
    }
    
    @PutMapping("/vaccine-program/{vaccineProgramId}")
    public ResponseEntity<VaccineProgramDTO> updateVaccineProgram(@RequestBody VaccineProgramRequest request, @PathVariable long vaccineProgramId) {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        VaccineProgramDTO vaccineProgramDTO = adminService.updateVaccineProgram(request, Long.parseLong(adminId), vaccineProgramId);
        return ResponseEntity.ok(vaccineProgramDTO);
    }

    @GetMapping("/vaccine-program")
    public ResponseEntity<List<VaccineProgramDTO>> getAllVaccineProgram() {
        String adminId = SecurityContextHolder.getContext().getAuthentication().getName();
        List<VaccineProgramDTO> vaccineProgramDTOList = adminService.getAllVaccineProgram(Long.parseLong(adminId));
        return ResponseEntity.ok(vaccineProgramDTOList);
    }

    @GetMapping("/vaccine-program/{vaccineProgramId}")
    public ResponseEntity<VaccineProgramDTO> getVaccineProgramById(@PathVariable long vaccineProgramId) {
        VaccineProgramDTO vaccineProgramDTO = adminService.getVaccineProgramById(vaccineProgramId);
        return ResponseEntity.ok(vaccineProgramDTO);
    }
    
    @DeleteMapping("/vaccine-program/{vaccineProgramId}")
    public ResponseEntity<Void> deleteVaccineProgram(@PathVariable long vaccineProgramId) {
        adminService.deleteVaccineProgram(vaccineProgramId);
        return ResponseEntity.noContent().build();
    }
}
